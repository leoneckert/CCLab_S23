function setup(){
    let cnv = createCanvas(400, 400);
    cnv.parent("canvasContainer");

}

function draw(){
    background(120, 40, 240);
}